# Keep ExoPlayer classes
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep WallpaperService classes
-keep class * extends android.service.wallpaper.WallpaperService { *; }

# Keep ViewModel classes
-keep class * extends androidx.lifecycle.ViewModel { *; }

# Keep data classes
-keep class com.videowallpaper.pro.data.** { *; }
