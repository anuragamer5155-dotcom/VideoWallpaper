package com.videowallpaper.pro.utils

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.videowallpaper.pro.service.VideoWallpaperService

/**
 * WallpaperApplier — handles launching the system wallpaper picker
 * pre-configured to set [VideoWallpaperService] as the live wallpaper.
 *
 * Note: On Android, you cannot silently set a live wallpaper without
 * user confirmation — the system always shows a picker/preview dialog.
 * This is by design for user privacy and security.
 */
object WallpaperApplier {

    private const val TAG = "WallpaperApplier"

    /**
     * Launches the system live wallpaper picker targeting [VideoWallpaperService].
     *
     * The system will show a preview and ask the user to confirm.
     * Returns true if the intent was successfully launched, false otherwise.
     */
    fun applyLiveWallpaper(context: Context): Boolean {
        return try {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(context, VideoWallpaperService::class.java)
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch wallpaper picker: ${e.message}", e)
            // Fallback: open generic wallpaper picker
            openGenericWallpaperPicker(context)
        }
    }

    /**
     * Fallback: opens the generic system wallpaper settings if the direct
     * live wallpaper intent fails (some older or custom Android versions).
     */
    private fun openGenericWallpaperPicker(context: Context): Boolean {
        return try {
            val intent = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Fallback wallpaper picker also failed: ${e.message}", e)
            false
        }
    }

    /**
     * Returns true if a live wallpaper is currently set AND it is [VideoWallpaperService].
     * Used to show the user the current status.
     */
    fun isOurWallpaperActive(context: Context): Boolean {
        return try {
            val manager = WallpaperManager.getInstance(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val info = manager.wallpaperInfo
                info?.component?.className == VideoWallpaperService::class.java.name
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking active wallpaper: ${e.message}", e)
            false
        }
    }
}
