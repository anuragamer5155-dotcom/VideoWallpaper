package com.videowallpaper.pro.data

import android.content.Context
import android.content.SharedPreferences

/**
 * WallpaperPreferences — lightweight SharedPreferences wrapper that persists
 * the user's wallpaper settings across app restarts and service recreations.
 *
 * Used by both the UI (to read/write settings) and the WallpaperService
 * (to read settings at draw time).
 */
class WallpaperPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "wallpaper_prefs"

        // Keys
        const val KEY_VIDEO_URI = "video_uri"
        const val KEY_IS_MUTED = "is_muted"
        const val KEY_FIT_MODE = "fit_mode"

        // Fit mode constants
        const val FIT_FILL = 0   // Fill screen, crop overflow
        const val FIT_FIT = 1    // Letterbox / pillarbox
        const val FIT_STRETCH = 2 // Stretch to fill (may distort)
    }

    /** URI string of the currently selected video, or null if none. */
    var videoUri: String?
        get() = prefs.getString(KEY_VIDEO_URI, null)
        set(value) = prefs.edit().putString(KEY_VIDEO_URI, value).apply()

    /** Whether audio should be muted. Defaults to false (audio on). */
    var isMuted: Boolean
        get() = prefs.getBoolean(KEY_IS_MUTED, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_MUTED, value).apply()

    /**
     * How the video is scaled to fit the screen.
     * One of [FIT_FILL], [FIT_FIT], or [FIT_STRETCH].
     */
    var fitMode: Int
        get() = prefs.getInt(KEY_FIT_MODE, FIT_FILL)
        set(value) = prefs.edit().putInt(KEY_FIT_MODE, value).apply()

    /** Returns true if a video has been selected by the user. */
    fun hasVideo(): Boolean = !videoUri.isNullOrEmpty()

    /** Clears all saved preferences (e.g., on reset). */
    fun clear() = prefs.edit().clear().apply()
}
