package com.videowallpaper.pro.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.SurfaceTexture
import android.net.Uri
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.Surface
import android.view.SurfaceHolder
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.videowallpaper.pro.data.WallpaperPreferences

/**
 * VideoWallpaperService — the core WallpaperService that drives the live wallpaper.
 *
 * Architecture:
 * - Extends [WallpaperService] and creates one [VideoEngine] per surface.
 * - Uses ExoPlayer for hardware-accelerated video decoding.
 * - Listens for screen-on/off broadcasts to pause/resume playback.
 * - Reads settings from [WallpaperPreferences] (URI, mute, fit mode).
 *
 * Performance optimizations:
 * - Hardware acceleration via ExoPlayer's surface rendering.
 * - Video is paused when screen is off (saves CPU/GPU).
 * - ExoPlayer handles buffering and codec selection automatically.
 */
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = VideoEngine()

    // ─────────────────────────────────────────────────────────────────────────

    inner class VideoEngine : Engine() {

        private val TAG = "VideoEngine"

        private var exoPlayer: ExoPlayer? = null
        private val prefs by lazy { WallpaperPreferences(this@VideoWallpaperService) }

        // SurfaceTexture + Surface used to route ExoPlayer output to the WallpaperService surface
        private var surfaceTexture: SurfaceTexture? = null
        private var playerSurface: Surface? = null

        private var isScreenOn = true
        private var isVisible = false

        /**
         * BroadcastReceiver to pause playback when the screen turns off,
         * and resume it when the screen turns back on.
         * This significantly reduces battery and CPU usage.
         */
        private val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        isScreenOn = false
                        pausePlayback()
                        Log.d(TAG, "Screen off: playback paused")
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        isScreenOn = true
                        if (isVisible) resumePlayback()
                        Log.d(TAG, "Screen on: playback resumed")
                    }
                }
            }
        }

        // ─── Engine lifecycle ─────────────────────────────────────────────────

        override fun onCreate(holder: SurfaceHolder?) {
            super.onCreate(holder)
            registerScreenReceiver()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder?) {
            super.onSurfaceCreated(holder)
            initializePlayer()
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder?,
            format: Int,
            width: Int,
            height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
            // If player is running, update the output surface
            holder?.surface?.let { surface ->
                exoPlayer?.setVideoSurface(surface)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            super.onSurfaceDestroyed(holder)
            releasePlayer()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            isVisible = visible
            if (visible && isScreenOn) {
                resumePlayback()
            } else {
                pausePlayback()
            }
        }

        override fun onDestroy() {
            super.onDestroy()
            releasePlayer()
            unregisterScreenReceiver()
        }

        // ─── Player management ────────────────────────────────────────────────

        /**
         * Initializes ExoPlayer with the saved video URI.
         * Configures looping, mute, and hardware acceleration.
         */
        private fun initializePlayer() {
            val uriString = prefs.videoUri ?: return
            val uri = Uri.parse(uriString)

            try {
                // Build ExoPlayer with hardware acceleration enabled by default
                val player = ExoPlayer.Builder(this@VideoWallpaperService)
                    .build()
                    .apply {
                        // Set up audio handling
                        val audioAttributes = AudioAttributes.Builder()
                            .setUsage(C.USAGE_MEDIA)
                            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                            .build()
                        setAudioAttributes(audioAttributes, false)

                        // Apply mute setting
                        volume = if (prefs.isMuted) 0f else 1f

                        // Loop video indefinitely
                        repeatMode = Player.REPEAT_MODE_ONE

                        // Attach to the wallpaper's surface for rendering
                        surfaceHolder?.surface?.let { setVideoSurface(it) }

                        // Load and prepare the video
                        setMediaItem(MediaItem.fromUri(uri))
                        prepare()
                        playWhenReady = true
                    }

                // Listen for errors
                player.addListener(object : Player.Listener {
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        Log.e(TAG, "Player error: ${error.message}", error)
                        // Attempt to recover by re-preparing
                        recoverFromError(uri)
                    }

                    override fun onVideoSizeChanged(videoSize: VideoSize) {
                        Log.d(TAG, "Video size: ${videoSize.width}x${videoSize.height}")
                    }
                })

                exoPlayer = player
                Log.d(TAG, "ExoPlayer initialized for URI: $uri")

            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize ExoPlayer: ${e.message}", e)
            }
        }

        /**
         * Attempts to recover from a playback error by re-preparing the player.
         * Called at most once to avoid infinite retry loops.
         */
        private fun recoverFromError(uri: Uri) {
            try {
                exoPlayer?.apply {
                    setMediaItem(MediaItem.fromUri(uri))
                    prepare()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Recovery failed: ${e.message}", e)
            }
        }

        /** Pauses video playback. Safe to call when player is null. */
        private fun pausePlayback() {
            exoPlayer?.playWhenReady = false
        }

        /** Resumes video playback. Safe to call when player is null. */
        private fun resumePlayback() {
            exoPlayer?.playWhenReady = true
        }

        /**
         * Releases ExoPlayer and all associated resources.
         * Must be called when the surface is destroyed to prevent leaks.
         */
        private fun releasePlayer() {
            try {
                exoPlayer?.apply {
                    stop()
                    clearVideoSurface()
                    release()
                }
                exoPlayer = null
                playerSurface?.release()
                playerSurface = null
                surfaceTexture?.release()
                surfaceTexture = null
                Log.d(TAG, "ExoPlayer released")
            } catch (e: Exception) {
                Log.e(TAG, "Error releasing player: ${e.message}", e)
            }
        }

        // ─── Screen receiver ──────────────────────────────────────────────────

        private fun registerScreenReceiver() {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            try {
                this@VideoWallpaperService.registerReceiver(screenReceiver, filter)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to register screen receiver: ${e.message}", e)
            }
        }

        private fun unregisterScreenReceiver() {
            try {
                this@VideoWallpaperService.unregisterReceiver(screenReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "Screen receiver not registered: ${e.message}")
            }
        }
    }
}
