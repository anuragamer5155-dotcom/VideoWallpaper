package com.videowallpaper.pro.data

/**
 * VideoFitMode — sealed class representing how the video is scaled
 * to fill the wallpaper surface.
 */
sealed class VideoFitMode(val value: Int, val label: String) {

    /** Fill the screen; crop the video if needed (most common for wallpapers). */
    object Fill : VideoFitMode(WallpaperPreferences.FIT_FILL, "Fill Screen")

    /** Fit the full video within the screen, adding letterbox/pillarbox bars. */
    object Fit : VideoFitMode(WallpaperPreferences.FIT_FIT, "Fit to Screen")

    /** Stretch the video to exactly match the screen (may distort). */
    object Stretch : VideoFitMode(WallpaperPreferences.FIT_STRETCH, "Stretch")

    companion object {
        /** All available modes in display order. */
        val all = listOf(Fill, Fit, Stretch)

        /** Returns the mode matching the given [value], defaulting to Fill. */
        fun fromValue(value: Int): VideoFitMode =
            all.firstOrNull { it.value == value } ?: Fill
    }
}
