package com.videowallpaper.pro.ui.main

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.videowallpaper.pro.R
import com.videowallpaper.pro.data.VideoFitMode
import com.videowallpaper.pro.databinding.ActivityMainBinding
import com.videowallpaper.pro.ui.preview.PreviewActivity
import com.videowallpaper.pro.utils.PermissionHelper
import com.videowallpaper.pro.utils.WallpaperApplier
import com.videowallpaper.pro.viewmodel.MainViewModel

/**
 * MainActivity — the app's entry point.
 *
 * Responsibilities:
 * - Request storage permission before allowing video selection.
 * - Launch the system file picker for video selection.
 * - Display the selected video thumbnail and metadata.
 * - Allow the user to toggle mute and change fit mode.
 * - Navigate to PreviewActivity for a fullscreen preview.
 * - Launch the system wallpaper picker to apply the live wallpaper.
 *
 * Follows MVVM: this activity only handles UI events and observes LiveData.
 * All business logic lives in [MainViewModel].
 */
class MainActivity : AppCompatActivity() {

    // View binding for type-safe view access
    private lateinit var binding: ActivityMainBinding

    // ViewModel survives configuration changes
    private val viewModel: MainViewModel by viewModels()

    // ─── Permission request launcher ──────────────────────────────────────────

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            openVideoPicker()
        } else {
            // Check if we should show rationale or go straight to settings
            val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                this,
                PermissionHelper.getRequiredPermission()
            )
            if (shouldShowRationale) {
                Toast.makeText(this, getString(R.string.permission_required), Toast.LENGTH_LONG).show()
            } else {
                // User permanently denied — direct them to app settings
                showPermissionDeniedDialog()
            }
        }
    }

    // ─── File picker launcher ─────────────────────────────────────────────────

    private val videoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { viewModel.onVideoSelected(it) }
    }

    // ─── Activity lifecycle ───────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupFitSpinner()
        setupClickListeners()
        observeViewModel()
    }

    // ─── UI setup ─────────────────────────────────────────────────────────────

    /**
     * Populates the fit mode spinner with [VideoFitMode] options.
     */
    private fun setupFitSpinner() {
        val labels = VideoFitMode.all.map { it.label }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.fitSpinner.adapter = adapter

        // Set initial selection from ViewModel state
        val currentMode = viewModel.fitMode.value ?: VideoFitMode.Fill
        binding.fitSpinner.setSelection(VideoFitMode.all.indexOf(currentMode))

        binding.fitSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    viewModel.setFitMode(VideoFitMode.all[position])
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
    }

    /**
     * Wires up button click handlers.
     */
    private fun setupClickListeners() {
        // Select Video button
        binding.selectVideoBtn.setOnClickListener {
            checkPermissionAndPickVideo()
        }

        // Preview button — open fullscreen preview activity
        binding.previewBtn.setOnClickListener {
            val uri = viewModel.videoUri.value
            if (uri == null) {
                showNoVideoDialog()
                return@setOnClickListener
            }
            val intent = Intent(this, PreviewActivity::class.java).apply {
                putExtra(PreviewActivity.EXTRA_VIDEO_URI, uri.toString())
                putExtra(PreviewActivity.EXTRA_IS_MUTED, viewModel.isMuted.value ?: false)
            }
            startActivity(intent)
        }

        // Apply Wallpaper button
        binding.applyWallpaperBtn.setOnClickListener {
            val uri = viewModel.videoUri.value
            if (uri == null) {
                showNoVideoDialog()
                return@setOnClickListener
            }
            applyWallpaper()
        }

        // Mute switch
        binding.muteSwitch.setOnCheckedChangeListener { _, isChecked ->
            viewModel.toggleMute(isChecked)
        }
    }

    // ─── ViewModel observation ────────────────────────────────────────────────

    /**
     * Observes LiveData from [MainViewModel] and updates the UI accordingly.
     */
    private fun observeViewModel() {
        // Show/hide thumbnail and placeholder based on URI availability
        viewModel.videoUri.observe(this) { uri ->
            val hasVideo = uri != null
            binding.placeholderLayout.visibility = if (hasVideo) View.GONE else View.VISIBLE
            binding.videoThumbnail.visibility = if (hasVideo) View.VISIBLE else View.GONE
            binding.playOverlay.visibility = if (hasVideo) View.VISIBLE else View.GONE
            binding.previewBtn.isEnabled = hasVideo
            binding.applyWallpaperBtn.isEnabled = hasVideo
        }

        // Update thumbnail image
        viewModel.thumbnail.observe(this) { bitmap ->
            if (bitmap != null) {
                binding.videoThumbnail.setImageBitmap(bitmap)
            }
        }

        // Update video name
        viewModel.videoName.observe(this) { name ->
            binding.videoNameText.text = name
        }

        // Update duration label
        viewModel.videoDuration.observe(this) { duration ->
            if (duration.isNotEmpty()) {
                binding.videoDurationText.text = "Duration: $duration"
                binding.videoDurationText.visibility = View.VISIBLE
            }
        }

        // Sync mute switch with ViewModel
        viewModel.isMuted.observe(this) { muted ->
            if (binding.muteSwitch.isChecked != muted) {
                binding.muteSwitch.isChecked = muted
            }
        }

        // Show errors as toasts
        viewModel.errorMessage.observe(this) { message ->
            if (!message.isNullOrEmpty()) {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                viewModel.clearError()
            }
        }

        // Show/hide loading indicator
        viewModel.isLoading.observe(this) { loading ->
            binding.selectVideoBtn.isEnabled = !loading
        }
    }

    // ─── Permission & file picking ────────────────────────────────────────────

    /**
     * Checks storage permission before opening the video picker.
     * Requests the permission if not yet granted.
     */
    private fun checkPermissionAndPickVideo() {
        if (PermissionHelper.hasStoragePermission(this)) {
            openVideoPicker()
        } else {
            permissionLauncher.launch(PermissionHelper.getRequiredPermission())
        }
    }

    /**
     * Opens the system file picker filtered to video files.
     */
    private fun openVideoPicker() {
        videoPickerLauncher.launch("video/*")
    }

    // ─── Wallpaper application ────────────────────────────────────────────────

    /**
     * Launches the system wallpaper picker targeting our [VideoWallpaperService].
     * The system will show a preview and ask the user to confirm.
     */
    private fun applyWallpaper() {
        val success = WallpaperApplier.applyLiveWallpaper(this)
        if (!success) {
            Toast.makeText(
                this,
                "Could not open wallpaper settings. Please set manually via Settings > Wallpaper.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ─── Dialogs ──────────────────────────────────────────────────────────────

    private fun showNoVideoDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.dialog_no_video_title))
            .setMessage(getString(R.string.dialog_no_video_message))
            .setPositiveButton(getString(R.string.ok), null)
            .show()
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permission Required")
            .setMessage(getString(R.string.permission_denied))
            .setPositiveButton(getString(R.string.open_settings)) { _, _ ->
                openAppSettings()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun openAppSettings() {
        val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = android.net.Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }
}
