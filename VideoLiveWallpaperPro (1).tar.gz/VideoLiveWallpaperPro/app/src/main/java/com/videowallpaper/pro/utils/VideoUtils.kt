package com.videowallpaper.pro.utils

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log

/**
 * VideoUtils — utility functions for extracting metadata and thumbnails from videos.
 *
 * Uses MediaMetadataRetriever which is available from API 10+.
 * All operations are safe: they return null/0 instead of throwing exceptions.
 */
object VideoUtils {

    private const val TAG = "VideoUtils"

    // Max resolution cap for low-end device optimization
    private const val MAX_THUMBNAIL_SIZE = 720

    /**
     * Extracts a thumbnail bitmap from the video at the given [uri].
     * Returns null if extraction fails.
     *
     * The thumbnail is captured from the first frame (time = 0 µs).
     * Resolution is capped at [MAX_THUMBNAIL_SIZE] for memory efficiency.
     */
    fun extractThumbnail(context: Context, uri: Uri): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            // Get frame at time 0 (first frame)
            val bitmap = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            bitmap?.let { scaleThumbnail(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to extract thumbnail: ${e.message}", e)
            null
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing retriever: ${e.message}")
            }
        }
    }

    /**
     * Returns the duration of the video at [uri] in milliseconds.
     * Returns 0 if the duration cannot be determined.
     */
    fun getVideoDuration(context: Context, uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationStr?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get video duration: ${e.message}", e)
            0L
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing retriever: ${e.message}")
            }
        }
    }

    /**
     * Returns the file name from a content URI, or a fallback label.
     */
    fun getVideoName(context: Context, uri: Uri): String {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                cursor.moveToFirst()
                if (nameIndex >= 0) cursor.getString(nameIndex) else "Video"
            } ?: "Video"
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get video name: ${e.message}", e)
            "Video"
        }
    }

    /**
     * Formats a duration in milliseconds as MM:SS or HH:MM:SS.
     */
    fun formatDuration(durationMs: Long): String {
        if (durationMs <= 0) return "0:00"
        val totalSeconds = durationMs / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%d:%02d", minutes, seconds)
        }
    }

    /**
     * Scales a bitmap down if it exceeds [MAX_THUMBNAIL_SIZE] in either dimension.
     * Preserves aspect ratio. Returns the original bitmap if no scaling is needed.
     */
    private fun scaleThumbnail(bitmap: Bitmap): Bitmap {
        val maxDim = MAX_THUMBNAIL_SIZE
        if (bitmap.width <= maxDim && bitmap.height <= maxDim) return bitmap

        val scale = maxDim.toFloat() / maxOf(bitmap.width, bitmap.height)
        val newWidth = (bitmap.width * scale).toInt()
        val newHeight = (bitmap.height * scale).toInt()

        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true).also {
            // Recycle original only if a new bitmap was created
            if (it !== bitmap) bitmap.recycle()
        }
    }
}
