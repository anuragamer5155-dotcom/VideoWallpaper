package com.videowallpaper.pro.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * PermissionHelper — centralizes storage permission logic.
 *
 * Android 13+ uses READ_MEDIA_VIDEO instead of READ_EXTERNAL_STORAGE.
 * This helper abstracts that difference so the activity doesn't need to worry.
 */
object PermissionHelper {

    /**
     * Returns the correct storage permission for the current Android version.
     * - API 33+ (Android 13): READ_MEDIA_VIDEO
     * - API 21-32: READ_EXTERNAL_STORAGE
     */
    fun getRequiredPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    /**
     * Returns true if the app already has permission to read videos from storage.
     */
    fun hasStoragePermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            getRequiredPermission()
        ) == PackageManager.PERMISSION_GRANTED
    }
}
