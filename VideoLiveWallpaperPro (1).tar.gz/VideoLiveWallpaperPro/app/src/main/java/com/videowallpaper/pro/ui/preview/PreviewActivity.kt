package com.videowallpaper.pro.ui.preview

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.videowallpaper.pro.R
import com.videowallpaper.pro.databinding.ActivityPreviewBinding
import com.videowallpaper.pro.utils.WallpaperApplier

/**
 * PreviewActivity — fullscreen video preview before applying as wallpaper.
 *
 * Shows the selected video playing in fullscreen (with correct aspect ratio)
 * so the user can verify it looks right before committing to apply it.
 *
 * Uses ExoPlayer directly with [PlayerView] for a smooth preview experience.
 * Includes a mute toggle and a direct "Apply as Wallpaper" button.
 */
class PreviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_VIDEO_URI = "extra_video_uri"
        const val EXTRA_IS_MUTED = "extra_is_muted"
    }

    private lateinit var binding: ActivityPreviewBinding
    private var exoPlayer: ExoPlayer? = null
    private var isMuted = false

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Enter fullscreen mode
        enableFullscreen()

        // Read extras
        val uriString = intent.getStringExtra(EXTRA_VIDEO_URI)
        isMuted = intent.getBooleanExtra(EXTRA_IS_MUTED, false)

        if (uriString == null) {
            finish()
            return
        }

        setupPlayer(Uri.parse(uriString))
        setupClickListeners()
        updateMuteIcon()
    }

    override fun onStart() {
        super.onStart()
        exoPlayer?.play()
    }

    override fun onStop() {
        super.onStop()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
    }

    // ─── Player setup ─────────────────────────────────────────────────────────

    /**
     * Initializes ExoPlayer and attaches it to the [PlayerView].
     * Configures looping, mute, and starts playback.
     */
    private fun setupPlayer(uri: Uri) {
        val player = ExoPlayer.Builder(this).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE  // Loop continuously
            volume = if (isMuted) 0f else 1f
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }

        binding.playerView.player = player
        exoPlayer = player
    }

    private fun releasePlayer() {
        exoPlayer?.apply {
            stop()
            release()
        }
        exoPlayer = null
    }

    // ─── UI ───────────────────────────────────────────────────────────────────

    private fun setupClickListeners() {
        // Back button
        binding.backBtn.setOnClickListener {
            finish()
        }

        // Mute toggle button
        binding.muteBtn.setOnClickListener {
            isMuted = !isMuted
            exoPlayer?.volume = if (isMuted) 0f else 1f
            updateMuteIcon()
        }

        // Apply wallpaper from preview screen
        binding.applyBtn.setOnClickListener {
            WallpaperApplier.applyLiveWallpaper(this)
        }
    }

    private fun updateMuteIcon() {
        val icon = if (isMuted) R.drawable.ic_volume_off else R.drawable.ic_volume
        binding.muteBtn.setImageResource(icon)
    }

    /**
     * Hides system UI (status bar, navigation bar) for a true fullscreen experience.
     * Handles both API 30+ (WindowInsetsController) and older versions.
     */
    private fun enableFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.apply {
                hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
        }
    }
}
