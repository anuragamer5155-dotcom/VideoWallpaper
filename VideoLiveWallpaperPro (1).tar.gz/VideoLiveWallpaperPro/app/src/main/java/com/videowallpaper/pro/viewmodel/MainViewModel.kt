package com.videowallpaper.pro.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.videowallpaper.pro.data.VideoFitMode
import com.videowallpaper.pro.data.WallpaperPreferences
import com.videowallpaper.pro.utils.VideoUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * MainViewModel — MVVM ViewModel for the main activity.
 *
 * Survives configuration changes (rotation) and performs all heavy work
 * (thumbnail extraction, metadata reading) off the main thread.
 *
 * Exposes LiveData so the UI can observe state changes safely.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = WallpaperPreferences(application)

    // ─── LiveData exposed to the UI ───────────────────────────────────────────

    /** Currently selected video URI. Null if no video has been picked. */
    private val _videoUri = MutableLiveData<Uri?>(
        prefs.videoUri?.let { Uri.parse(it) }
    )
    val videoUri: LiveData<Uri?> = _videoUri

    /** Thumbnail bitmap extracted from the selected video. */
    private val _thumbnail = MutableLiveData<Bitmap?>()
    val thumbnail: LiveData<Bitmap?> = _thumbnail

    /** Display name of the selected video file. */
    private val _videoName = MutableLiveData<String>()
    val videoName: LiveData<String> = _videoName

    /** Duration string (e.g. "3:42") of the selected video. */
    private val _videoDuration = MutableLiveData<String>()
    val videoDuration: LiveData<String> = _videoDuration

    /** Whether audio is muted. Synced with SharedPreferences. */
    private val _isMuted = MutableLiveData<Boolean>(prefs.isMuted)
    val isMuted: LiveData<Boolean> = _isMuted

    /** Current video fit mode. Synced with SharedPreferences. */
    private val _fitMode = MutableLiveData<VideoFitMode>(VideoFitMode.fromValue(prefs.fitMode))
    val fitMode: LiveData<VideoFitMode> = _fitMode

    /** Error message to display. Null when no error. */
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    /** True while loading thumbnail/metadata. */
    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading

    // ─── Init: restore state ─────────────────────────────────────────────────

    init {
        // If a video URI was previously saved, load its metadata
        prefs.videoUri?.let { uriString ->
            loadVideoMetadata(Uri.parse(uriString))
        }
    }

    // ─── Public methods ───────────────────────────────────────────────────────

    /**
     * Called when the user picks a new video.
     * Persists the URI and loads metadata off-thread.
     */
    fun onVideoSelected(uri: Uri) {
        prefs.videoUri = uri.toString()
        _videoUri.value = uri
        loadVideoMetadata(uri)
    }

    /**
     * Toggles mute state and persists the new value.
     */
    fun toggleMute(muted: Boolean) {
        prefs.isMuted = muted
        _isMuted.value = muted
    }

    /**
     * Updates the fit mode and persists it.
     */
    fun setFitMode(mode: VideoFitMode) {
        prefs.fitMode = mode.value
        _fitMode.value = mode
    }

    /** Clears any pending error message after it has been shown. */
    fun clearError() {
        _errorMessage.value = null
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    /**
     * Extracts thumbnail, name, and duration from the video URI.
     * Runs on IO dispatcher, posts results back to the main thread via LiveData.
     */
    private fun loadVideoMetadata(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            val context = getApplication<Application>()

            try {
                // Run heavy IO work on background thread
                val result = withContext(Dispatchers.IO) {
                    val name = VideoUtils.getVideoName(context, uri)
                    val durationMs = VideoUtils.getVideoDuration(context, uri)
                    val duration = VideoUtils.formatDuration(durationMs)
                    val thumb = VideoUtils.extractThumbnail(context, uri)
                    Triple(name, duration, thumb)
                }

                _videoName.value = result.first
                _videoDuration.value = result.second
                _thumbnail.value = result.third

                if (result.third == null) {
                    _errorMessage.value = "Could not load thumbnail. Video may be unsupported."
                }
            } catch (e: Exception) {
                _errorMessage.value = "Failed to load video: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
}
