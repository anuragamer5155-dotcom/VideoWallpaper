# Video Live Wallpaper Pro — Setup & Build Instructions

## Project Overview

A native Android app that lets users pick any video from their phone and use it as a live wallpaper.

**Min SDK:** 21 (Android 5.0)  
**Target SDK:** 34 (Android 14)  
**Language:** Kotlin  
**Architecture:** MVVM  
**Video Player:** ExoPlayer (Media3)

---

## File Structure

```
VideoLiveWallpaperPro/
├── build.gradle                         # Root Gradle config
├── settings.gradle                      # Module inclusion
├── gradle.properties                    # JVM args, AndroidX flags
└── app/
    ├── build.gradle                     # App module dependencies
    ├── proguard-rules.pro               # Release minification rules
    └── src/main/
        ├── AndroidManifest.xml          # Permissions, activities, service
        ├── java/com/videowallpaper/pro/
        │   ├── data/
        │   │   ├── WallpaperPreferences.kt  # SharedPreferences wrapper
        │   │   └── VideoFitMode.kt          # Fit mode sealed class
        │   ├── service/
        │   │   └── VideoWallpaperService.kt # Core WallpaperService + ExoPlayer engine
        │   ├── ui/
        │   │   ├── main/
        │   │   │   └── MainActivity.kt      # Main screen (video picker, settings)
        │   │   └── preview/
        │   │       └── PreviewActivity.kt   # Fullscreen video preview
        │   ├── utils/
        │   │   ├── PermissionHelper.kt      # Storage permission abstraction
        │   │   ├── VideoUtils.kt            # Thumbnail, duration, name helpers
        │   │   └── WallpaperApplier.kt      # System wallpaper picker launcher
        │   └── viewmodel/
        │       └── MainViewModel.kt         # MVVM ViewModel
        └── res/
            ├── drawable/                    # Vector icons, gradients
            ├── layout/                      # Activity layouts
            ├── mipmap-*/                    # Launcher icons
            ├── values/
            │   ├── strings.xml
            │   ├── colors.xml
            │   └── themes.xml
            └── xml/
                └── wallpaper_info.xml       # Live wallpaper metadata
```

---

## Prerequisites

1. **Android Studio** — Latest stable version (Hedgehog / Iguana or newer)
   - Download: https://developer.android.com/studio

2. **JDK 17** — Android Studio includes this. If building from CLI, install via:
   ```
   brew install openjdk@17  # macOS
   sudo apt install openjdk-17-jdk  # Ubuntu/Debian
   ```

3. **Android SDK** — SDK 21–34 installed via Android Studio SDK Manager

---

## Setup in Android Studio

### Step 1: Open the Project

1. Launch Android Studio
2. Click **File → Open**
3. Navigate to the `VideoLiveWallpaperPro/` folder and click **OK**
4. Wait for Gradle sync to complete (first sync downloads dependencies — may take 2–5 minutes)

### Step 2: Sync Gradle

If Android Studio doesn't auto-sync:
- Click **File → Sync Project with Gradle Files**, OR
- Click the "Sync Now" banner that appears at the top

### Step 3: Connect a Device or Start an Emulator

**Physical device (recommended for live wallpapers):**
1. Enable Developer Options on your phone: Settings → About → tap Build Number 7 times
2. Enable USB Debugging: Settings → Developer Options → USB Debugging
3. Connect via USB and allow the connection when prompted

**Emulator:**
1. Open AVD Manager (Device icon in toolbar)
2. Create a Virtual Device with API 21+ and x86_64 image
3. Note: Live wallpapers may not work on all emulators — test on a real device for best results

---

## Running the App

### From Android Studio:
1. Select your device from the device dropdown in the toolbar
2. Click the **Run ▶** button (or press **Shift+F10**)
3. The app installs and launches automatically

### From Command Line:
```bash
# In the VideoLiveWallpaperPro/ directory:
./gradlew installDebug

# Then launch manually on the device, or:
adb shell am start -n com.videowallpaper.pro/.ui.main.MainActivity
```

---

## Building the APK

### Debug APK (for testing, no signing required):
```bash
./gradlew assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

### Release APK (for distribution):

**Step 1:** Create a signing keystore (one-time setup):
```bash
keytool -genkey -v -keystore my-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias my-key-alias
```

**Step 2:** Configure signing in `app/build.gradle` (add inside `android {}` block):
```groovy
signingConfigs {
    release {
        storeFile file("my-release-key.jks")
        storePassword "your_store_password"
        keyAlias "my-key-alias"
        keyPassword "your_key_password"
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        // ... existing config ...
    }
}
```

**Step 3:** Build:
```bash
./gradlew assembleRelease
```
Output: `app/build/outputs/apk/release/app-release.apk`

### From Android Studio GUI:
1. **Build → Generate Signed Bundle / APK**
2. Choose APK
3. Create or use existing keystore
4. Select release build variant
5. Click Finish

---

## How to Use the App

1. **Open** Video Live Wallpaper Pro on your device
2. Tap **Select Video** — grant storage permission when prompted
3. Choose any video from your gallery
4. Adjust settings:
   - **Mute toggle** — enable/disable audio for the wallpaper
   - **Video Fit** — choose Fill, Fit, or Stretch
5. Tap **Preview** — see the video in fullscreen before applying
6. Tap **Apply Wallpaper** — the system wallpaper picker opens
7. Tap **Set Wallpaper** in the system picker to confirm
8. Choose **Home screen**, **Lock screen**, or **Both**

---

## Applying as Lock Screen Wallpaper

On Android, live wallpapers can be applied to the lock screen on supported devices:
- The system picker will give you options for home/lock/both after you tap **Set Wallpaper**
- Not all devices support live wallpapers on the lock screen (Samsung, Pixel fully support it)

---

## Performance Notes

- **Hardware acceleration** is enabled by default via ExoPlayer's codec pipeline
- **Screen-off pause**: playback automatically pauses when the screen turns off, saving battery
- **Resolution cap**: VideoUtils caps thumbnails at 720p for memory efficiency
- **Loop**: video loops seamlessly via ExoPlayer's `REPEAT_MODE_ONE`
- **Low-end devices**: ExoPlayer automatically selects the best codec available

---

## Troubleshooting

| Problem | Solution |
|---|---|
| Gradle sync fails | Check Android SDK path in File → SDK Manager |
| "No video selected" after picking | Grant storage permission; try a different video format |
| Blank wallpaper after applying | Make sure the service is running; re-select and re-apply |
| App crashes on old device | Ensure minSdk 21 target and that Media3 libs are downloaded |
| Live wallpaper doesn't appear in picker | Uninstall/reinstall the app to re-register the service |

---

## Supported Video Formats

ExoPlayer supports all standard Android-supported formats:
- **MP4** (H.264, H.265) ✅ Best performance
- **MKV** ✅
- **WebM** / VP8 / VP9 ✅
- **AVI** — limited support on some devices
- **MOV** — may require codec support

For best performance, use MP4 with H.264 encoding at 720p or lower.
